USE DB_Assignment;


CREATE TABLE Category (
    CategoryID INT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Description TEXT
);

CREATE TABLE Supplier (
    SupplierID INT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    ContactEmail VARCHAR(100),
    ContactPhone VARCHAR(15)
);

CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Description TEXT,
    Price DECIMAL(10, 2) NOT NULL,
    CategoryID INT,
    SupplierID INT,
    StockQuantity INT NOT NULL,
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID),
    FOREIGN KEY (SupplierID) REFERENCES Supplier(SupplierID)
);

CREATE TABLE Employee (
    EmployeeID INT PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Position VARCHAR(50),
    HireDate DATE
);

CREATE TABLE PaymentType (
    PaymentTypeID INT PRIMARY KEY,
    Description VARCHAR(100) NOT NULL
);

CREATE TABLE Customer (
    CustomerID INT PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Email VARCHAR(100),
    Phone VARCHAR(15)
);

CREATE TABLE Transaction (
    TransactionID INT PRIMARY KEY,
    DateOfTransaction DATE NOT NULL,
    TimeOfTransaction TIME NOT NULL,
    TotalAmount DECIMAL(10, 2) NOT NULL,
    EmployeeID INT,
    PaymentTypeID INT,
    CustomerID INT,
    FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID),
    FOREIGN KEY (PaymentTypeID) REFERENCES PaymentType(PaymentTypeID),
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID)
);

CREATE TABLE TransactionDetail (
    TransactionDetailID INT PRIMARY KEY,
    TransactionID INT,
    ProductID INT,
    Quantity INT NOT NULL,
    PriceAtTimeOfSale DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (TransactionID) REFERENCES Transaction(TransactionID),
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID)
);

CREATE TABLE InventoryLog (
    InventoryLogID INT PRIMARY KEY,
    ProductID INT,
    ChangeDate DATE NOT NULL,
    ChangeQuantity INT NOT NULL,
    Reason TEXT,
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID)
);
