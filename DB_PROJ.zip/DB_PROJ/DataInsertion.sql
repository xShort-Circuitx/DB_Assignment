-- Insert Categories
INSERT INTO Category (CategoryID, Name, Description) VALUES (1, 'Beverages', 'Drinks and refreshments');
INSERT INTO Category (CategoryID, Name, Description) VALUES (2, 'Snacks', 'Chips, biscuits, and other snacks');
INSERT INTO Category (CategoryID, Name, Description) VALUES (3, 'Dairy', 'Milk, cheese, and other dairy products');
INSERT INTO Category (CategoryID, Name, Description) VALUES (4, 'Bakery', 'Bread, cakes, and pastries');
INSERT INTO Category (CategoryID, Name, Description) VALUES (5, 'Frozen Foods', 'Frozen meals and desserts');
INSERT INTO Category (CategoryID, Name, Description) VALUES (6, 'Produce', 'Fresh fruits and vegetables');
INSERT INTO Category (CategoryID, Name, Description) VALUES (7, 'Meat', 'Fresh and processed meat products');
INSERT INTO Category (CategoryID, Name, Description) VALUES (8, 'Seafood', 'Fresh and frozen seafood');
INSERT INTO Category (CategoryID, Name, Description) VALUES (9, 'Pantry', 'Canned goods and dry foods');
INSERT INTO Category (CategoryID, Name, Description) VALUES (10, 'Personal Care', 'Hygiene and beauty products');

-- Insert Suppliers
INSERT INTO Supplier (SupplierID, Name, ContactEmail, ContactPhone) VALUES (1, 'ABC Suppliers', 'abc@example.com', '123-456-7890');
INSERT INTO Supplier (SupplierID, Name, ContactEmail, ContactPhone) VALUES (2, 'XYZ Distributors', 'xyz@example.com', '987-654-3210');
INSERT INTO Supplier (SupplierID, Name, ContactEmail, ContactPhone) VALUES (3, 'Global Foods', 'global@example.com', '456-789-0123');
INSERT INTO Supplier (SupplierID, Name, ContactEmail, ContactPhone) VALUES (4, 'Fresh Produce Inc.', 'produce@example.com', '789-012-3456');
INSERT INTO Supplier (SupplierID, Name, ContactEmail, ContactPhone) VALUES (5, 'Dairy Farmers', 'dairy@example.com', '234-567-8901');
INSERT INTO Supplier (SupplierID, Name, ContactEmail, ContactPhone) VALUES (6, 'Seafood Market', 'seafood@example.com', '567-890-1234');
INSERT INTO Supplier (SupplierID, Name, ContactEmail, ContactPhone) VALUES (7, 'Meat Supplies Co.', 'meat@example.com', '890-123-4567');
INSERT INTO Supplier (SupplierID, Name, ContactEmail, ContactPhone) VALUES (8, 'Bakery Goods', 'bakery@example.com', '012-345-6789');
INSERT INTO Supplier (SupplierID, Name, ContactEmail, ContactPhone) VALUES (9, 'Frozen Foods Ltd.', 'frozen@example.com', '345-678-9012');
INSERT INTO Supplier (SupplierID, Name, ContactEmail, ContactPhone) VALUES (10, 'Pantry Essentials', 'pantry@example.com', '678-901-2345');

-- Insert Products
INSERT INTO Product (ProductID, Name, Description, Price, CategoryID, SupplierID, StockQuantity) VALUES (1, 'Coca-Cola', 'Soft drink', 1.25, 1, 1, 100);
INSERT INTO Product (ProductID, Name, Description, Price, CategoryID, SupplierID, StockQuantity) VALUES (2, 'Pepsi', 'Soft drink', 1.25, 1, 1, 100);
INSERT INTO Product (ProductID, Name, Description, Price, CategoryID, SupplierID, StockQuantity) VALUES (3, 'Lays Chips', 'Potato chips', 1.50, 2, 2, 200);
INSERT INTO Product (ProductID, Name, Description, Price, CategoryID, SupplierID, StockQuantity) VALUES (4, 'Doritos', 'Tortilla chips', 1.75, 2, 2, 200);
INSERT INTO Product (ProductID, Name, Description, Price, CategoryID, SupplierID, StockQuantity) VALUES (5, 'Milk', 'Whole milk', 2.00, 3, 5, 150);
INSERT INTO Product (ProductID, Name, Description, Price, CategoryID, SupplierID, StockQuantity) VALUES (6, 'Cheese', 'Cheddar cheese', 3.00, 3, 5, 100);
INSERT INTO Product (ProductID, Name, Description, Price, CategoryID, SupplierID, StockQuantity) VALUES (7, 'Bread', 'White bread', 2.50, 4, 8, 180);
INSERT INTO Product (ProductID, Name, Description, Price, CategoryID, SupplierID, StockQuantity) VALUES (8, 'Croissant', 'Buttery croissant', 1.75, 4, 8, 150);
INSERT INTO Product (ProductID, Name, Description, Price, CategoryID, SupplierID, StockQuantity) VALUES (9, 'Frozen Pizza', 'Pepperoni pizza', 5.00, 5, 9, 80);
INSERT INTO Product (ProductID, Name, Description, Price, CategoryID, SupplierID, StockQuantity) VALUES (10, 'Frozen Vegetables', 'Mixed vegetables', 3.50, 5, 9, 120);

-- Insert Employees
INSERT INTO Employee (EmployeeID, FirstName, LastName, Position, HireDate) VALUES (1, 'Alice', 'Johnson', 'Cashier', '2020-01-15');
INSERT INTO Employee (EmployeeID, FirstName, LastName, Position, HireDate) VALUES (2, 'Bob', 'Brown', 'Manager', '2019-03-22');
INSERT INTO Employee (EmployeeID, FirstName, LastName, Position, HireDate) VALUES (3, 'Charlie', 'Davis', 'Stock Clerk', '2021-07-10');
INSERT INTO Employee (EmployeeID, FirstName, LastName, Position, HireDate) VALUES (4, 'Dana', 'Evans', 'Cashier', '2022-09-01');
INSERT INTO Employee (EmployeeID, FirstName, LastName, Position, HireDate) VALUES (5, 'Eve', 'Foster', 'Assistant Manager', '2018-11-30');
INSERT INTO Employee (EmployeeID, FirstName, LastName, Position, HireDate) VALUES (6, 'Frank', 'Green', 'Cleaner', '2021-04-25');
INSERT INTO Employee (EmployeeID, FirstName, LastName, Position, HireDate) VALUES (7, 'Grace', 'Harris', 'Cashier', '2023-02-17');
INSERT INTO Employee (EmployeeID, FirstName, LastName, Position, HireDate) VALUES (8, 'Hank', 'Ives', 'Security', '2020-05-15');
INSERT INTO Employee (EmployeeID, FirstName, LastName, Position, HireDate) VALUES (9, 'Ivy', 'Jones', 'Stock Clerk', '2021-06-22');
INSERT INTO Employee (EmployeeID, FirstName, LastName, Position, HireDate) VALUES (10, 'Jack', 'King', 'Manager', '2017-08-10');

-- Insert Payment Types
INSERT INTO PaymentType (PaymentTypeID, Description) VALUES (1, 'Cash');
INSERT INTO PaymentType (PaymentTypeID, Description) VALUES (2, 'Credit Card');
INSERT INTO PaymentType (PaymentTypeID, Description) VALUES (3, 'Debit Card');
INSERT INTO PaymentType (PaymentTypeID, Description) VALUES (4, 'Mobile Payment');
INSERT INTO PaymentType (PaymentTypeID, Description) VALUES (5, 'Gift Card');
INSERT INTO PaymentType (PaymentTypeID, Description) VALUES (6, 'Check');
INSERT INTO PaymentType (PaymentTypeID, Description) VALUES (7, 'Wire Transfer');
INSERT INTO PaymentType (PaymentTypeID, Description) VALUES (8, 'Cryptocurrency');
INSERT INTO PaymentType (PaymentTypeID, Description) VALUES (9, 'Store Credit');
INSERT INTO PaymentType (PaymentTypeID, Description) VALUES (10, 'Other');

-- Insert Customers
INSERT INTO Customer (CustomerID, FirstName, LastName, Email, Phone) VALUES (1, 'Laura', 'Nelson', 'laura@example.com', '111-222-3333');
INSERT INTO Customer (CustomerID, FirstName, LastName, Email, Phone) VALUES (2, 'Mike', 'Olsen', 'mike@example.com', '222-333-4444');
INSERT INTO Customer (CustomerID, FirstName, LastName, Email, Phone) VALUES (3, 'Nina', 'Peterson', 'nina@example.com', '333-444-5555');
INSERT INTO Customer (CustomerID, FirstName, LastName, Email, Phone) VALUES (4, 'Oscar', 'Quincy', 'oscar@example.com', '444-555-6666');
INSERT INTO Customer (CustomerID, FirstName, LastName, Email, Phone) VALUES (5, 'Paula', 'Reed', 'paula@example.com', '555-666-7777');
INSERT INTO Customer (CustomerID, FirstName, LastName, Email, Phone) VALUES (6, 'Quinn', 'Smith', 'quinn@example.com', '666-777-8888');
INSERT INTO Customer (CustomerID, FirstName, LastName, Email, Phone) VALUES (7, 'Rita', 'Thomas', 'rita@example.com', '777-888-9999');
INSERT INTO Customer (CustomerID, FirstName, LastName, Email, Phone) VALUES (8, 'Sam', 'Underwood', 'sam@example.com', '888-999-0000');
INSERT INTO Customer (CustomerID, FirstName, LastName, Email, Phone) VALUES (9, 'Tina', 'Vaughn', 'tina@example.com', '999-000-1111');
INSERT INTO Customer (CustomerID, FirstName, LastName, Email, Phone) VALUES (10, 'Uma', 'Wilson', 'uma@example.com', '000-111-2222');

-- Insert Transactions
INSERT INTO Transaction (TransactionID, DateOfTransaction, TimeOfTransaction, TotalAmount, EmployeeID, PaymentTypeID, CustomerID) VALUES (1, '2024-06-01', '14:23:00', 5.75, 1, 1, 1);
INSERT INTO Transaction (TransactionID, DateOfTransaction, TimeOfTransaction, TotalAmount, EmployeeID, PaymentTypeID, CustomerID) VALUES (2, '2024-06-01', '15:30:00', 12.50, 2, 2, 2);
INSERT INTO Transaction (TransactionID, DateOfTransaction, TimeOfTransaction, TotalAmount, EmployeeID, PaymentTypeID, CustomerID) VALUES (3, '2024-06-01', '16:45:00', 8.25, 3, 3, 3);
INSERT INTO Transaction (TransactionID, DateOfTransaction, TimeOfTransaction, TotalAmount, EmployeeID, PaymentTypeID, CustomerID) VALUES (4, '2024-06-01', '17:00:00', 10.00, 4, 4, 4);
INSERT INTO Transaction (TransactionID, DateOfTransaction, TimeOfTransaction, TotalAmount, EmployeeID, PaymentTypeID, CustomerID) VALUES (5, '2024-06-01', '18:15:00', 15.75, 5, 5, 5);
INSERT INTO Transaction (TransactionID, DateOfTransaction, TimeOfTransaction, TotalAmount, EmployeeID, PaymentTypeID, CustomerID) VALUES (6, '2024-06-01', '19:20:00', 20.00, 6, 6, 6);
INSERT INTO Transaction (TransactionID, DateOfTransaction, TimeOfTransaction, TotalAmount, EmployeeID, PaymentTypeID, CustomerID) VALUES (7, '2024-06-01', '20:30:00', 25.50, 7, 7, 7);
INSERT INTO Transaction (TransactionID, DateOfTransaction, TimeOfTransaction, TotalAmount, EmployeeID, PaymentTypeID, CustomerID) VALUES (8, '2024-06-01', '21:45:00', 30.75, 8, 8, 8);
INSERT INTO Transaction (TransactionID, DateOfTransaction, TimeOfTransaction, TotalAmount, EmployeeID, PaymentTypeID, CustomerID) VALUES (9, '2024-06-01', '22:10:00', 35.00, 9, 9, 9);
INSERT INTO Transaction (TransactionID, DateOfTransaction, TimeOfTransaction, TotalAmount, EmployeeID, PaymentTypeID, CustomerID) VALUES (10, '2024-06-01', '23:00:00', 40.50, 10, 10, 10);

-- Insert Transaction Details
INSERT INTO TransactionDetail (TransactionDetailID, TransactionID, ProductID, Quantity, PriceAtTimeOfSale) VALUES (1, 1, 1, 2, 1.25);
INSERT INTO TransactionDetail (TransactionDetailID, TransactionID, ProductID, Quantity, PriceAtTimeOfSale) VALUES (2, 1, 3, 1, 1.50);
INSERT INTO TransactionDetail (TransactionDetailID, TransactionID, ProductID, Quantity, PriceAtTimeOfSale) VALUES (3, 2, 2, 3, 1.25);
INSERT INTO TransactionDetail (TransactionDetailID, TransactionID, ProductID, Quantity, PriceAtTimeOfSale) VALUES (4, 2, 4, 2, 1.75);
INSERT INTO TransactionDetail (TransactionDetailID, TransactionID, ProductID, Quantity, PriceAtTimeOfSale) VALUES (5, 3, 5, 1, 2.00);
INSERT INTO TransactionDetail (TransactionDetailID, TransactionID, ProductID, Quantity, PriceAtTimeOfSale) VALUES (6, 3, 6, 2, 3.00);
INSERT INTO TransactionDetail (TransactionDetailID, TransactionID, ProductID, Quantity, PriceAtTimeOfSale) VALUES (7, 4, 7, 3, 2.50);
INSERT INTO TransactionDetail (TransactionDetailID, TransactionID, ProductID, Quantity, PriceAtTimeOfSale) VALUES (8, 4, 8, 2, 1.75);
INSERT INTO TransactionDetail (TransactionDetailID, TransactionID, ProductID, Quantity, PriceAtTimeOfSale) VALUES (9, 5, 9, 1, 5.00);
INSERT INTO TransactionDetail (TransactionDetailID, TransactionID, ProductID, Quantity, PriceAtTimeOfSale) VALUES (10, 5, 10, 3, 3.50);

-- Insert Inventory Logs
INSERT INTO InventoryLog (InventoryLogID, ProductID, ChangeDate, ChangeQuantity, Reason) VALUES (1, 1, '2024-06-01', -2, 'Sale');
INSERT INTO InventoryLog (InventoryLogID, ProductID, ChangeDate, ChangeQuantity, Reason) VALUES (2, 3, '2024-06-01', -1, 'Sale');
INSERT INTO InventoryLog (InventoryLogID, ProductID, ChangeDate, ChangeQuantity, Reason) VALUES (3, 2, '2024-06-01', -3, 'Sale');
INSERT INTO InventoryLog (InventoryLogID, ProductID, ChangeDate, ChangeQuantity, Reason) VALUES (4, 4, '2024-06-01', -2, 'Sale');
INSERT INTO InventoryLog (InventoryLogID, ProductID, ChangeDate, ChangeQuantity, Reason) VALUES (5, 5, '2024-06-01', -1, 'Sale');
INSERT INTO InventoryLog (InventoryLogID, ProductID, ChangeDate, ChangeQuantity, Reason) VALUES (6, 6, '2024-06-01', -2, 'Sale');
INSERT INTO InventoryLog (InventoryLogID, ProductID, ChangeDate, ChangeQuantity, Reason) VALUES (7, 7, '2024-06-01', -3, 'Sale');
INSERT INTO InventoryLog (InventoryLogID, ProductID, ChangeDate, ChangeQuantity, Reason) VALUES (8, 8, '2024-06-01', -2, 'Sale');
INSERT INTO InventoryLog (InventoryLogID, ProductID, ChangeDate, ChangeQuantity, Reason) VALUES (9, 9, '2024-06-01', -1, 'Sale');
INSERT INTO InventoryLog (InventoryLogID, ProductID, ChangeDate, ChangeQuantity, Reason) VALUES (10, 10, '2024-06-01', -3, 'Sale');
