
-- 1 Selling a Product to a Customer

-- 1.1 Insert a new transaction
INSERT INTO Transaction (TransactionID, DateOfTransaction, TimeOfTransaction, TotalAmount, EmployeeID, PaymentTypeID, CustomerID)
VALUES (11, '2024-06-02', '14:00:00', 10.50, 1, 1, 1);

-- 1.2 Insert transaction details
INSERT INTO TransactionDetail (TransactionDetailID, TransactionID, ProductID, Quantity, PriceAtTimeOfSale)
VALUES (11, 11, 1, 3, 1.25), -- Coca-Cola
       (12, 11, 4, 2, 1.75); -- Doritos

-- 1.3 Update stock quantity for the products
UPDATE Product
SET StockQuantity = StockQuantity - 3
WHERE ProductID = 1;

UPDATE Product
SET StockQuantity = StockQuantity - 2
WHERE ProductID = 4;

-- 1.4 Insert into InventoryLog
INSERT INTO InventoryLog (InventoryLogID, ProductID, ChangeDate, ChangeQuantity, Reason)
VALUES (11, 1, '2024-06-02', -3, 'Sale'),
       (12, 4, '2024-06-02', -2, 'Sale');
       
-- 2 Display the Last Time All Customers Bought Something
SELECT c.CustomerID, c.FirstName, c.LastName, MAX(t.DateOfTransaction) AS LastPurchaseDate
FROM Customer c
LEFT JOIN Transaction t ON c.CustomerID = t.CustomerID
GROUP BY c.CustomerID, c.FirstName, c.LastName;


-- 3 Display the Most Bought Category of Products
SELECT cat.CategoryID, cat.Name, SUM(td.Quantity) AS TotalQuantitySold
FROM TransactionDetail td
JOIN Product p ON td.ProductID = p.ProductID
JOIN Category cat ON p.CategoryID = cat.CategoryID
GROUP BY cat.CategoryID, cat.Name
ORDER BY TotalQuantitySold DESC
LIMIT 1;

-- 4 Display the Customer Who Bought the Most in Terms of Amount
SELECT c.CustomerID, c.FirstName, c.LastName, SUM(t.TotalAmount) AS TotalSpent
FROM Customer c
JOIN Transaction t ON c.CustomerID = t.CustomerID
GROUP BY c.CustomerID, c.FirstName, c.LastName
ORDER BY TotalSpent DESC
LIMIT 1;

-- 5 Display the Customers Who Bought the Most from Dairy
SELECT c.CustomerID, c.FirstName, c.LastName, SUM(td.Quantity) AS TotalDairyBought
FROM Customer c
JOIN Transaction t ON c.CustomerID = t.CustomerID
JOIN TransactionDetail td ON t.TransactionID = td.TransactionID
JOIN Product p ON td.ProductID = p.ProductID
WHERE p.CategoryID = 3 -- Assuming 3 is the ID for Dairy category
GROUP BY c.CustomerID, c.FirstName, c.LastName
ORDER BY TotalDairyBought DESC
LIMIT 1;

